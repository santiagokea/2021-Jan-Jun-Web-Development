<?php
  // redirect
  // header('Location: /login'); // on error
  header('Location: /profile'); // on success




